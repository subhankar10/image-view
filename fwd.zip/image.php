<?php include "head.php" ?>
<ul>

<li><?php include "body.php" ?></li>
<li><?php include "body.php" ?></li>
<li><?php include "body.php" ?></li>
<li><?php include "body.php" ?></li>
<li><?php include "body.php" ?></li>

</ul>

